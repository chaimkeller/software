"c:\fordtm\netz\1134-aco.pro",157.075,258.75,22.6
"c:\fordtm\netz\1135-aco.pro",158.675,259.625,31.2
Version,2,0,0
