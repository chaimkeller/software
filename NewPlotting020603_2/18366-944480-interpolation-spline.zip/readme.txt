Interpolation spline--------------------
Url     : http://codes-sources.commentcamarche.net/source/18366-interpolation-splineAuteur  : cuqDate    : 02/08/2013
Licence :
=========

Ce document intitul� � Interpolation spline � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Le corps du programme n'est pas de moi. J'ai modifi&eacute; une source existante
 trouv&eacute;e sur le Net pour un traitement en 3D. Cette source permet le trai
tement de diff&eacute;rentes courbes Spline. Ce programme est tr&egrave;s visuel
, il permet de bien voir la diff&eacute;rence de trac&eacute; selon le type de l
a Spline. De plus il permet d'avoir une d&eacute;composition de la spline en pet
its segments de droite. Ce qui est tr&egrave;s utiles par exemple pour les gens 
qui veulent piloter une petite machine de fraisage, simuler une trajectoire d&ea
cute;crite en spline etc .
<br />
<br />L'origine du programme est italienne .
 J'ai laiss&eacute; les commentaires en italien. C'est facile &agrave; comprendr
e en vous retrouvez les coordonn&eacute;es de l'auteur d'origine  : F. Languasco

<br />
<br />a+
<br /><a name='conclusion'></a><h2> Conclusion : </h2>
<br
 />CNote concernant l'auteur originale de la source : Vous trouverez sur son sit
e pas mal de source VB6. J'ai parcouru toute ces sources et j'ai retenu pour vou
s :
<br />
<br />SurFit: Visu en 3D d'un terrain avec calcul des lignes de niv
eau.  A voir absolument !
<br /><a href='http://www.flanguasco.org/VisualBasic/
SurFit.ZIP' target='_blank'>http://www.flanguasco.org/VisualBasic/SurFit.ZIP</a>

<br />
<br />Caleido : Repr&eacute;sentation d'une courbe avec effet cal&eacu
te;idoscopique
<br /><a href='http://www.flanguasco.org/VisualBasic/Caleido.ZIP
' target='_blank'>http://www.flanguasco.org/VisualBasic/Caleido.ZIP</a>
<br />

<br />Fraczn2c : Repr&eacute;sentation de fractal Absolument g&eacute;nial !
<
br /><a href='http://www.flanguasco.org/VisualBasic/FracZn2C.ZIP' target='_blank
'>http://www.flanguasco.org/VisualBasic/FracZn2C.ZIP</a>
<br />
<br />CurveFam
ose : Les courbes fameuse J'ai retrouv&eacute; dedans la cardioide (mon sujet de
 math au bac il a y de nombreuses ann&eacute;es et oui p&eacute;p&eacute; il est
 temps de se coucher). Une source a voir absolument pour ceux qui aime les maths
  ou les &eacute;tudiants de terminale.
<br /><a href='http://www.flanguasco.or
g/VisualBasic/CurveFamose.ZIP' target='_blank'>http://www.flanguasco.org/VisualB
asic/CurveFamose.ZIP</a>
<br />
<br />PoliRad : Calcul des racines d'une polyn
omial
<br /><a href='http://www.flanguasco.org/VisualBasic/PoliRad.ZIP' target=
'_blank'>http://www.flanguasco.org/VisualBasic/PoliRad.ZIP</a>
<br />
<br />Et
 d'autres ..
